import { Switch, Route, Router as WouterRouter } from "wouter";
import Landing from "@/pages/Landing";
import Domains from "@/pages/Domains";
import Dashboard from "@/pages/Dashboard";
import Login from "@/pages/Login";
import AuthCallback from "@/pages/AuthCallback";
import RTLPath from "@/pages/paths/RTLPath";
import VerificationPath from "@/pages/paths/VerificationPath";
import PhysicalDesignPath from "@/pages/paths/PhysicalDesignPath";
import AnalogPath from "@/pages/paths/AnalogPath";
import FPGAPath from "@/pages/paths/FPGAPath";
import EmbeddedPath from "@/pages/paths/EmbeddedPath";
import DFTPath from "@/pages/paths/DFTPath";
import ResearchPath from "@/pages/paths/ResearchPath";
import NotFound from "@/pages/not-found";
import Navbar from "@/components/Navbar";

export default function App() {
  return (
    <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
      <Navbar />
      <main className="min-h-screen bg-black">
        <Switch>
          <Route path="/" component={Landing} />
          <Route path="/domains" component={Domains} />
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/login" component={Login} />
          <Route path="/auth/callback" component={AuthCallback} />
          <Route path="/path/rtl" component={RTLPath} />
          <Route path="/path/verification" component={VerificationPath} />
          <Route path="/path/physical-design" component={PhysicalDesignPath} />
          <Route path="/path/analog" component={AnalogPath} />
          <Route path="/path/fpga" component={FPGAPath} />
          <Route path="/path/embedded" component={EmbeddedPath} />
          <Route path="/path/dft" component={DFTPath} />
          <Route path="/path/research" component={ResearchPath} />
          <Route component={NotFound} />
        </Switch>
      </main>
    </WouterRouter>
  );
}
